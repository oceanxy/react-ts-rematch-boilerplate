export interface Routes {
  history: any;
  location: any;
  match: any;
  route: any;
  staticContext: any;
}
