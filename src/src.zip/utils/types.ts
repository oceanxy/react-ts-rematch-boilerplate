export type ObjLike = {
  [props: string]: any;
};
